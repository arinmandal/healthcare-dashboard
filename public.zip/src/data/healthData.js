export const healthCardsData = [
  { icon: "🫁", title: "Lungs", date: "26 Okt 2021", status: "issue" },
  { icon: "🦷", title: "Teeth", date: "26 Okt 2021", status: "healthy" },
  { icon: "🦴", title: "Bone", date: "26 Okt 2021", status: "needCheckup" },
];